#логин пользователя
userlogin="t.taran"

#1С ЭБ
bash 1CCryptoExtensionChrFFSetupLin64.sh
bash 1CFileExtensionChrFFSetupLin64.sh
# bash /tmp/ExtraCryptoAPIChromeSetupLin64.sh
cp -r /root/bin/1CFileSystemExtension /usr/bin/
cp -r /root/bin/1CCryptoExtension /usr/bin/
# cp -r /root/bin/ExtraCryptoAPI /usr/bin/
chmod -R 777 /usr/bin/1CCryptoExtension
chown -R $userlogin:domain\ users /usr/bin/1CCryptoExtension
chmod -R 777 /usr/bin/1CFileSystemExtension
chown -R $userlogin:domain\ users /usr/bin/1CFileSystemExtension
# chmod -R 777 /usr/bin/ExtraCryptoAPI
# chown -R $userlogin:domain\ users /usr/bin/ExtraCryptoAPI
cp -r /root/.config/google-chrome/NativeMessagingHosts /home/ROSIM.LOC/$userlogin/.config/chromium-gost/
sed -i 's/root/usr/' /home/ROSIM.LOC/$userlogin/.config/chromium-gost/NativeMessagingHosts/com.1c.enterprise.cryptoextension.694.json
sed -i 's/root/usr/' /home/ROSIM.LOC/$userlogin/.config/chromium-gost/NativeMessagingHosts/com.1c.enterprise.filesystemext.0397.json
# sed -i 's/root/usr/' /home/ROSIM.LOC/$userlogin/.config/chromium-gost/NativeMessagingHosts/com.1c.enterprise.extracryptoapi.30224.json
